package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersonController {
	@Autowired
	DataV1Repo v1repo;
	@Autowired
	DataV2Repo v2repo;
	
	//   URI VERSIONING
	 @GetMapping("/cse/v1/students")
	 public List<CseDataV1> getV1Data(){
		 return v1repo.findAll();
	 }
	 
	 @GetMapping("/cse/v2/students")
	 public List<CseDataV2> getV2Data(){
		 return v2repo.findAll();
	 }
	 
	 // PARAMETER VERSIONING
	 @GetMapping(value="/cse/students",params="version1")
	 public List<CseDataV1> getDataByV1(){
		 return v1repo.findAll();
	 }
	 
	 @GetMapping(value="/cse/students",params="version2")
	 public List<CseDataV2> getDataByV2(){
		 return v2repo.findAll();
	 }
	 
	 
	 // CUSTOM HEADER VERSIONING
	 @GetMapping(value="/cse/mydata",headers="X-API-VERSION=1")
	 public List<CseDataV1> getDataByHeaderV1(){
		 return v1repo.findAll();
	 }
	 
	 @GetMapping(value="/cse/mydata",headers="X-API-VERSION=2")
	 public List<CseDataV2> getDataByHeaderV2(){
		 return v2repo.findAll();
	 }
	 
	 // ACCEPT VERSIONING
	 @GetMapping(value="/cse/data",produces="application/cse.v1+json")
	 public List<CseDataV1> getDataByAcceptV1(){
		 return v1repo.findAll();
	 }
	 
	 @GetMapping(value="/cse/data",produces="application/cse.v2+json")
	 public List<CseDataV2> getDataByAcceptV2(){
		 return v2repo.findAll();
	 }
	 
	 
	 
	 
	 
	
	

}
