package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot16Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot16Application.class, args);
	}

}
