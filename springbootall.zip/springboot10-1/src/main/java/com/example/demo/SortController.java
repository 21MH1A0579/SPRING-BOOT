package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SortController {
	
	@Autowired
	SortService cse;
	
	@PostMapping("/cse/insert")
	public SortEntity insertdata(@RequestBody SortEntity data) {
		
		return cse.insertdata(data);
		
	}
	@GetMapping("/cse/{field}")
	public List<SortEntity> sortdata(@PathVariable("field") String field){
		return cse.sortdata(field);
		
	}
	@GetMapping("/cse/{offset}/{pagesize}")
	public Page<SortEntity>csepage(@PathVariable int offset,@PathVariable int pagesize){
		
		Page<SortEntity> pagedata=cse.pageoff(offset,pagesize);
		return pagedata;
	}
	

}
