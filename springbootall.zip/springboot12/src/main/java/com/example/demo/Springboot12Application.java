package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot12Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot12Application.class, args);
	}

}
