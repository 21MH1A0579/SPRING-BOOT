package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CseOAuthController {
	
	
	@GetMapping("/cse/home")
	public String home() {
		return "Welcome to Homepage";
	}
	
	@GetMapping("/cse/user")
	public String User() {
		return "WELCOME TO SECURED PAGE";
	}
}
